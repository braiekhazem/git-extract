
import { GitProvider } from "@/types";

const GITHUB_API_BASE = "https://api.github.com";
const GITLAB_API_BASE = "https://gitlab.com/api/v4";

export interface RepoInfo {
  owner: string;
  name: string;
  provider: GitProvider;
  branch?: string;
}

export interface FileItem {
  id: string;
  name: string;
  path: string;
  type: "file" | "dir";
  size?: number;
  download_url?: string;
  children?: FileItem[];
  selected?: boolean;
}

export const parseRepoUrl = (url: string): RepoInfo | null => {
  try {
    const urlObj = new URL(url);
    const pathSegments = urlObj.pathname.split("/").filter(Boolean);
    
    // Check if it's GitHub
    if (urlObj.hostname === "github.com" && pathSegments.length >= 2) {
      const [owner, name] = pathSegments;
      let branch = undefined;
      
      // Check if there's a branch specified
      if (pathSegments.length > 2 && pathSegments[2] === "tree" && pathSegments.length > 3) {
        branch = pathSegments[3];
      }
      
      return {
        owner,
        name,
        provider: "github",
        branch,
      };
    }
    
    // Check if it's GitLab
    else if (urlObj.hostname === "gitlab.com" && pathSegments.length >= 2) {
      // GitLab URLs can have groups/subgroups before the project name
      const name = pathSegments[pathSegments.length - 1];
      const owner = pathSegments.slice(0, pathSegments.length - 1).join("/");
      let branch = undefined;
      
      // Check if there's a branch specified
      if (url.includes("/-/tree/")) {
        const branchMatch = url.match(/\/-\/tree\/([^/]+)/);
        if (branchMatch && branchMatch[1]) {
          branch = branchMatch[1];
        }
      }
      
      return {
        owner,
        name,
        provider: "gitlab",
        branch,
      };
    }
  } catch (error) {
    console.error("Error parsing repo URL:", error);
  }
  
  return null;
};

export const fetchRepoBranches = async (repoInfo: RepoInfo): Promise<string[]> => {
  try {
    if (repoInfo.provider === "github") {
      const response = await fetch(`${GITHUB_API_BASE}/repos/${repoInfo.owner}/${repoInfo.name}/branches`);
      if (!response.ok) throw new Error(`GitHub API error: ${response.status}`);
      const branches = await response.json();
      return branches.map((branch: any) => branch.name);
    } else if (repoInfo.provider === "gitlab") {
      const response = await fetch(`${GITLAB_API_BASE}/projects/${encodeURIComponent(`${repoInfo.owner}/${repoInfo.name}`)}/repository/branches`);
      if (!response.ok) throw new Error(`GitLab API error: ${response.status}`);
      const branches = await response.json();
      return branches.map((branch: any) => branch.name);
    }
  } catch (error) {
    console.error("Error fetching branches:", error);
  }
  
  return [];
};

export const fetchDefaultBranch = async (repoInfo: RepoInfo): Promise<string> => {
  try {
    if (repoInfo.provider === "github") {
      const response = await fetch(`${GITHUB_API_BASE}/repos/${repoInfo.owner}/${repoInfo.name}`);
      if (!response.ok) throw new Error(`GitHub API error: ${response.status}`);
      const repo = await response.json();
      return repo.default_branch;
    } else if (repoInfo.provider === "gitlab") {
      const response = await fetch(`${GITLAB_API_BASE}/projects/${encodeURIComponent(`${repoInfo.owner}/${repoInfo.name}`)}`);
      if (!response.ok) throw new Error(`GitLab API error: ${response.status}`);
      const repo = await response.json();
      return repo.default_branch;
    }
  } catch (error) {
    console.error("Error fetching default branch:", error);
  }
  
  return "main"; // Fallback to main if we can't determine the default branch
};

export const fetchRepoContents = async (repoInfo: RepoInfo, path: string = ""): Promise<FileItem[]> => {
  try {
    const branch = repoInfo.branch || "main";
    
    if (repoInfo.provider === "github") {
      const response = await fetch(`${GITHUB_API_BASE}/repos/${repoInfo.owner}/${repoInfo.name}/contents/${path}?ref=${branch}`);
      if (!response.ok) throw new Error(`GitHub API error: ${response.status}`);
      
      const contents = await response.json();
      return Array.isArray(contents) ? contents.map(item => ({
        id: item.sha,
        name: item.name,
        path: item.path,
        type: item.type === "dir" ? "dir" : "file",
        size: item.size,
        download_url: item.download_url,
        children: item.type === "dir" ? [] : undefined,
        selected: false
      })) : [];
    } else if (repoInfo.provider === "gitlab") {
      const encodedPath = path ? `/${encodeURIComponent(path)}` : "";
      const response = await fetch(`${GITLAB_API_BASE}/projects/${encodeURIComponent(`${repoInfo.owner}/${repoInfo.name}`)}/repository/tree?path=${encodedPath}&ref=${branch}`);
      if (!response.ok) throw new Error(`GitLab API error: ${response.status}`);
      
      const contents = await response.json();
      return contents.map((item: any) => ({
        id: item.id,
        name: item.name,
        path: item.path,
        type: item.type === "tree" ? "dir" : "file",
        children: item.type === "tree" ? [] : undefined,
        selected: false
      }));
    }
  } catch (error) {
    console.error("Error fetching repository contents:", error);
  }
  
  return [];
};

export const fetchFileContent = async (repoInfo: RepoInfo, filePath: string): Promise<string | null> => {
  try {
    const branch = repoInfo.branch || "main";
    
    if (repoInfo.provider === "github") {
      // For GitHub we can directly use the raw content URL
      const response = await fetch(`https://raw.githubusercontent.com/${repoInfo.owner}/${repoInfo.name}/${branch}/${filePath}`);
      if (!response.ok) throw new Error(`GitHub raw content error: ${response.status}`);
      
      return await response.text();
    } else if (repoInfo.provider === "gitlab") {
      const response = await fetch(`${GITLAB_API_BASE}/projects/${encodeURIComponent(`${repoInfo.owner}/${repoInfo.name}`)}/repository/files/${encodeURIComponent(filePath)}/raw?ref=${branch}`);
      if (!response.ok) throw new Error(`GitLab API error: ${response.status}`);
      
      return await response.text();
    }
  } catch (error) {
    console.error("Error fetching file content:", error);
  }
  
  return null;
};

export const fetchFileSize = async (repoInfo: RepoInfo, filePath: string): Promise<number | null> => {
  try {
    const branch = repoInfo.branch || "main";
    
    if (repoInfo.provider === "github") {
      const response = await fetch(`${GITHUB_API_BASE}/repos/${repoInfo.owner}/${repoInfo.name}/contents/${filePath}?ref=${branch}`);
      if (!response.ok) throw new Error(`GitHub API error: ${response.status}`);
      
      const fileInfo = await response.json();
      return fileInfo.size;
    } else if (repoInfo.provider === "gitlab") {
      // GitLab doesn't provide file size in the tree API, we need to get it from file API
      const response = await fetch(`${GITLAB_API_BASE}/projects/${encodeURIComponent(`${repoInfo.owner}/${repoInfo.name}`)}/repository/files/${encodeURIComponent(filePath)}?ref=${branch}`);
      if (!response.ok) throw new Error(`GitLab API error: ${response.status}`);
      
      const fileInfo = await response.json();
      return fileInfo.size;
    }
  } catch (error) {
    console.error("Error fetching file size:", error);
  }
  
  return null;
};

export const getFileIcon = (fileName: string): string => {
  const extension = fileName.split('.').pop()?.toLowerCase() || '';
  
  // Common file types
  switch(extension) {
    case 'js':
    case 'jsx':
    case 'ts':
    case 'tsx':
      return 'code';
    case 'css':
    case 'scss':
    case 'sass':
    case 'less':
      return 'paintbrush';
    case 'html':
    case 'htm':
    case 'xml':
      return 'code-2';
    case 'md':
    case 'markdown':
    case 'txt':
      return 'file-text';
    case 'json':
      return 'braces';
    case 'yml':
    case 'yaml':
      return 'file-json';
    case 'png':
    case 'jpg':
    case 'jpeg':
    case 'gif':
    case 'svg':
    case 'webp':
      return 'image';
    case 'pdf':
      return 'file-type';
    case 'zip':
    case 'tar':
    case 'gz':
    case 'rar':
      return 'archive';
    case 'mp3':
    case 'wav':
    case 'ogg':
      return 'music';
    case 'mp4':
    case 'webm':
    case 'avi':
      return 'video';
    case 'gitignore':
    case 'npmignore':
      return 'git-branch';
    case 'env':
    case 'env.example':
    case 'env.local':
      return 'key';
    case 'lock':
      return 'lock';
    case 'license':
    case 'licence':
      return 'file-check';
    default:
      return 'file';
  }
};

export const formatFileSize = (bytes?: number): string => {
  if (bytes === undefined) return 'Unknown size';
  if (bytes === 0) return '0 bytes';
  
  const k = 1024;
  const sizes = ['bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const getFileExtension = (fileName: string): string => {
  const parts = fileName.split('.');
  return parts.length > 1 ? parts[parts.length - 1].toLowerCase() : '';
};
