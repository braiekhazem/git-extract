import React, { useState, useEffect, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { Download, Github, Gitlab, LoaderCircle, Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SidebarLayout } from "@/components/sidebar-layout";
import { FileExplorer } from "@/components/file-explorer";
import { ModeToggle } from "@/components/mode-toggle";
import { ThemeProvider } from "@/components/theme-provider";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import JSZip from "jszip";
import { FileItem, RepoInfo, fetchDefaultBranch, fetchFileContent, fetchRepoBranches, fetchRepoContents, formatFileSize, parseRepoUrl } from "@/lib/api";

const Index = () => {
  const { toast } = useToast();
  
  // State management
  const [repoUrl, setRepoUrl] = useState("");
  const [directLink, setDirectLink] = useState("");
  const [repoInfo, setRepoInfo] = useState<RepoInfo | null>(null);
  const [branch, setBranch] = useState<string>("");
  const [branches, setBranches] = useState<string[]>([]);
  const [files, setFiles] = useState<FileItem[]>([]);
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const [fetchingFiles, setFetchingFiles] = useState(false);
  const [zipProgress, setZipProgress] = useState<number | null>(null);
  const [directDownloading, setDirectDownloading] = useState(false);

  // Load repo when URL changes
  const loadRepo = useCallback(async () => {
    if (!repoUrl.trim()) return;
    
    setLoading(true);
    setFiles([]);
    setExpandedNodes(new Set());
    setSelectedItems(new Set());
    
    try {
      const parsedRepo = parseRepoUrl(repoUrl);
      if (!parsedRepo) {
        toast({
          title: "Invalid repository URL",
          description: "Please enter a valid GitHub or GitLab repository URL",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }
      
      setRepoInfo(parsedRepo);
      
      // Fetch branches and default branch
      const repoBranches = await fetchRepoBranches(parsedRepo);
      setBranches(repoBranches);
      
      let defaultBranch;
      if (parsedRepo.branch) {
        defaultBranch = parsedRepo.branch;
      } else {
        defaultBranch = await fetchDefaultBranch(parsedRepo);
      }
      
      setBranch(defaultBranch);
      
      // Update repo info with branch
      const updatedRepoInfo = {
        ...parsedRepo,
        branch: defaultBranch,
      };
      setRepoInfo(updatedRepoInfo);
      
      // Fetch initial contents
      const contents = await fetchRepoContents(updatedRepoInfo);
      setFiles(contents);
      
      toast({
        title: "Repository loaded",
        description: `${parsedRepo.owner}/${parsedRepo.name} (${defaultBranch})`,
      });
    } catch (error) {
      console.error("Error loading repository:", error);
      toast({
        title: "Error loading repository",
        description: "There was an error loading the repository. Please check the URL and try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [repoUrl, toast]);

  // Direct link download handler
  const handleDirectDownload = async () => {
    if (!directLink.trim()) {
      toast({
        title: "Empty link",
        description: "Please enter a valid file or folder link",
        variant: "destructive",
      });
      return;
    }
    
    setDirectDownloading(true);
    
    try {
      // Parse the direct link
      const parsedRepo = parseRepoUrl(directLink);
      if (!parsedRepo) {
        toast({
          title: "Invalid URL",
          description: "Please enter a valid GitHub or GitLab file/folder URL",
          variant: "destructive",
        });
        setDirectDownloading(false);
        return;
      }
      
      // Extract the file/folder path from the URL
      let filePath = "";
      const url = new URL(directLink);
      
      if (parsedRepo.provider === "github") {
        // Handle GitHub URL format
        const segments = url.pathname.split('/');
        const blobOrTreeIndex = segments.indexOf("blob") !== -1 
          ? segments.indexOf("blob") 
          : segments.indexOf("tree");
        
        if (blobOrTreeIndex !== -1 && segments.length > blobOrTreeIndex + 2) {
          // Skip owner, repo, blob/tree, branch
          filePath = segments.slice(blobOrTreeIndex + 2).join('/');
          parsedRepo.branch = segments[blobOrTreeIndex + 1];
        }
      } else if (parsedRepo.provider === "gitlab") {
        // Handle GitLab URL format
        if (url.pathname.includes("/-/blob/") || url.pathname.includes("/-/tree/")) {
          const parts = url.pathname.split("/-/");
          if (parts.length > 1) {
            const typeAndPath = parts[1].split('/');
            // typeAndPath[0] is 'blob' or 'tree', typeAndPath[1] is branch
            parsedRepo.branch = typeAndPath[1];
            filePath = typeAndPath.slice(2).join('/');
          }
        }
      }
      
      if (!filePath) {
        toast({
          title: "Could not determine file path",
          description: "Please make sure you're using a direct file or folder link",
          variant: "destructive",
        });
        setDirectDownloading(false);
        return;
      }
      
      const isFile = directLink.includes("/blob/") || 
                    (directLink.includes("/-/blob/"));
      
      if (isFile) {
        // Single file download
        const content = await fetchFileContent(parsedRepo, filePath);
        if (content === null) {
          throw new Error("Failed to fetch file content");
        }
        
        // Create a ZIP with the single file
        const zip = new JSZip();
        const fileName = filePath.split('/').pop() || "file";
        zip.file(fileName, content);
        
        // Generate and download the ZIP
        const zipBlob = await zip.generateAsync({ type: "blob" });
        const url = URL.createObjectURL(zipBlob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${fileName}.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        toast({
          title: "Download complete",
          description: `Successfully downloaded ${fileName}`,
        });
      } else {
        // Folder download - fetch all contents recursively
        const folderName = filePath.split('/').pop() || parsedRepo.name;
        
        // Initialize ZIP
        const zip = new JSZip();
        let totalFiles = 0;
        let processedFiles = 0;
        
        // Function to recursively fetch folder contents
        const fetchFolderContents = async (path: string, zipFolder: JSZip) => {
          const contents = await fetchRepoContents(parsedRepo!, path);
          
          for (const item of contents) {
            if (item.type === "file") {
              totalFiles++;
              const content = await fetchFileContent(parsedRepo!, item.path);
              if (content !== null) {
                const relativePath = item.path.replace(filePath + '/', '');
                zipFolder.file(relativePath, content);
                processedFiles++;
                setZipProgress(Math.floor((processedFiles / totalFiles) * 100));
              }
            } else if (item.type === "dir") {
              // Create folder in zip
              const subFolder = zipFolder.folder(item.name);
              if (subFolder) {
                // Recursively process subfolder
                await fetchFolderContents(item.path, subFolder);
              }
            }
          }
        };
        
        // Start fetching folder contents
        setZipProgress(0);
        await fetchFolderContents(filePath, zip.folder(folderName) || zip);
        
        // Generate and download ZIP
        const zipBlob = await zip.generateAsync({ type: "blob" }, (metadata) => {
          setZipProgress(metadata.percent);
        });
        
        const url = URL.createObjectURL(zipBlob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${folderName}.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        toast({
          title: "Download complete",
          description: `Successfully downloaded folder: ${folderName}`,
        });
      }
      
    } catch (error) {
      console.error("Error downloading from direct link:", error);
      toast({
        title: "Download failed",
        description: "There was an error processing your download. Please try again.",
        variant: "destructive",
      });
    } finally {
      setDirectDownloading(false);
      setZipProgress(null);
      setDirectLink("");
    }
  };

  // Toggle node expansion
  const handleToggleNode = useCallback(async (path: string) => {
    // Find the node in the file tree
    const findAndUpdateNode = async (items: FileItem[], nodePath: string): Promise<FileItem[]> => {
      return Promise.all(items.map(async (item) => {
        if (item.path === nodePath) {
          const isExpanding = !expandedNodes.has(nodePath);
          
          // If expanding and children are empty, fetch them
          if (isExpanding && item.type === "dir" && (!item.children || item.children.length === 0)) {
            try {
              setFetchingFiles(true);
              const children = await fetchRepoContents(repoInfo!, item.path);
              setFetchingFiles(false);
              return { ...item, children };
            } catch (error) {
              console.error("Error fetching directory contents:", error);
              setFetchingFiles(false);
              return item;
            }
          }
          
          return item;
        } else if (item.children) {
          return { ...item, children: await findAndUpdateNode(item.children, nodePath) };
        } else {
          return item;
        }
      }));
    };
    
    if (repoInfo) {
      const updatedFiles = await findAndUpdateNode(files, path);
      setFiles(updatedFiles);
      
      setExpandedNodes((prev) => {
        const newSet = new Set(prev);
        if (newSet.has(path)) {
          newSet.delete(path);
        } else {
          newSet.add(path);
        }
        return newSet;
      });
    }
  }, [files, expandedNodes, repoInfo]);

  // Toggle item selection
  const handleToggleSelect = useCallback((item: FileItem, selected: boolean) => {
    setSelectedItems((prev) => {
      const newSet = new Set(prev);
      if (selected) {
        newSet.add(item.path);
      } else {
        newSet.delete(item.path);
      }
      return newSet;
    });
  }, []);

  // Handle branch change
  const handleBranchChange = async (newBranch: string) => {
    if (!repoInfo || newBranch === branch) return;
    
    setBranch(newBranch);
    setLoading(true);
    setFiles([]);
    setExpandedNodes(new Set());
    setSelectedItems(new Set());
    
    try {
      const updatedRepoInfo = {
        ...repoInfo,
        branch: newBranch,
      };
      
      setRepoInfo(updatedRepoInfo);
      
      const contents = await fetchRepoContents(updatedRepoInfo);
      setFiles(contents);
    } catch (error) {
      console.error("Error changing branch:", error);
      toast({
        title: "Error changing branch",
        description: `Failed to load branch: ${newBranch}`,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Download selected files as ZIP
  const downloadSelectedFiles = async () => {
    if (!repoInfo || selectedItems.size === 0) {
      toast({
        title: "No files selected",
        description: "Please select at least one file or folder to download",
        variant: "destructive",
      });
      return;
    }
    
    setZipProgress(0);
    
    try {
      const zip = new JSZip();
      let totalFiles = 0;
      let processedFiles = 0;
      
      // Count total files to process
      const countFiles = async (items: FileItem[], paths: Set<string>) => {
        for (const item of items) {
          if (paths.has(item.path)) {
            if (item.type === "file") {
              totalFiles++;
            } else if (item.type === "dir" && item.children) {
              await countFiles(item.children, new Set([item.path]));
            }
          } else if (item.children) {
            await countFiles(item.children, paths);
          }
        }
      };
      
      // Add files to zip
      const addFilesToZip = async (items: FileItem[], paths: Set<string>, parentPath = "") => {
        for (const item of items) {
          if (paths.has(item.path)) {
            if (item.type === "file") {
              const content = await fetchFileContent(repoInfo, item.path);
              if (content !== null) {
                zip.file(parentPath + item.name, content);
                processedFiles++;
                setZipProgress(Math.floor((processedFiles / totalFiles) * 100));
              }
            } else if (item.type === "dir" && item.children) {
              const folderPath = parentPath + item.name + "/";
              // Process all files in this folder
              await addAllFilesInFolder(item.children, folderPath);
            }
          } else if (item.children) {
            await addFilesToZip(item.children, paths, parentPath);
          }
        }
      };
      
      // Add all files in a folder to zip
      const addAllFilesInFolder = async (items: FileItem[], parentPath = "") => {
        for (const item of items) {
          if (item.type === "file") {
            const content = await fetchFileContent(repoInfo, item.path);
            if (content !== null) {
              zip.file(parentPath + item.name, content);
              processedFiles++;
              setZipProgress(Math.floor((processedFiles / totalFiles) * 100));
            }
          } else if (item.type === "dir" && item.children) {
            const folderPath = parentPath + item.name + "/";
            await addAllFilesInFolder(item.children, folderPath);
          }
        }
      };
      
      // First count total files
      await countFiles(files, selectedItems);
      
      // Then add them to zip
      await addFilesToZip(files, selectedItems);
      
      // Generate zip
      const zipBlob = await zip.generateAsync({ type: "blob" }, (metadata) => {
        setZipProgress(metadata.percent);
      });
      
      // Create download link
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${repoInfo.name}_files.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      toast({
        title: "Download complete",
        description: `Successfully downloaded ${processedFiles} files`,
      });
    } catch (error) {
      console.error("Error creating zip:", error);
      toast({
        title: "Error creating ZIP file",
        description: "There was an error creating the ZIP file. Please try again.",
        variant: "destructive",
      });
    } finally {
      setZipProgress(null);
    }
  };

  // Clear repository
  const handleClearRepo = () => {
    setRepoUrl("");
    setRepoInfo(null);
    setBranch("");
    setBranches([]);
    setFiles([]);
    setExpandedNodes(new Set());
    setSelectedItems(new Set());
    setDirectLink("");
  };

  // Get total selected files count (including files in selected folders)
  const getSelectedCount = useCallback(() => {
    if (selectedItems.size === 0) return 0;
    
    let count = 0;
    
    const countSelectedFiles = (items: FileItem[]) => {
      items.forEach((item) => {
        if (selectedItems.has(item.path)) {
          if (item.type === "file") {
            count++;
          } else if (item.type === "dir") {
            // If a folder is selected, count all its files recursively
            if (item.children) {
              countAllFiles(item.children);
            }
          }
        } else if (item.children) {
          countSelectedFiles(item.children);
        }
      });
    };
    
    const countAllFiles = (items: FileItem[]) => {
      items.forEach((item) => {
        if (item.type === "file") {
          count++;
        } else if (item.type === "dir" && item.children) {
          countAllFiles(item.children);
        }
      });
    };
    
    countSelectedFiles(files);
    return count;
  }, [files, selectedItems]);

  // Render file explorer sidebar
  const renderSidebar = () => {
    return (
      <FileExplorer
        files={files}
        loading={loading || fetchingFiles}
        onToggleNode={handleToggleNode}
        onToggleSelect={handleToggleSelect}
        expandedNodes={expandedNodes}
        selectedItems={selectedItems}
      />
    );
  };

  return (
    <ThemeProvider defaultTheme="system">
      <SidebarLayout sidebar={renderSidebar()}>
        <div className="container max-w-5xl mx-auto px-4 py-8">
          <div className="flex flex-col space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex flex-col">
                <h1 className="text-3xl font-bold tracking-tight">RepoGrabZip</h1>
                <p className="text-muted-foreground">
                  Download files from GitHub and GitLab repositories
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <ModeToggle />
              </div>
            </div>

            {/* URL Input */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Download Files</CardTitle>
                <CardDescription>
                  Browse repositories or directly download files/folders
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="repo" className="w-full">
                  <TabsList className="grid grid-cols-2 mb-4">
                    <TabsTrigger value="repo">Browse Repository</TabsTrigger>
                    <TabsTrigger value="direct">Direct Link</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="repo" className="mt-0">
                    <div className="flex flex-col md:flex-row gap-3">
                      <div className="flex-1 relative">
                        <div className="absolute left-3 top-2.5 text-muted-foreground">
                          {repoInfo?.provider === "github" ? (
                            <Github className="h-5 w-5" />
                          ) : repoInfo?.provider === "gitlab" ? (
                            <Gitlab className="h-5 w-5" />
                          ) : (
                            <Search className="h-5 w-5" />
                          )}
                        </div>
                        <Input
                          type="text"
                          placeholder="https://github.com/username/repository"
                          className="pl-10"
                          value={repoUrl}
                          onChange={(e) => setRepoUrl(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && loadRepo()}
                        />
                        {repoUrl && (
                          <button
                            className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground"
                            onClick={() => setRepoUrl("")}
                          >
                            <X className="h-5 w-5" />
                          </button>
                        )}
                      </div>
                      <Button onClick={loadRepo} disabled={loading || !repoUrl.trim()}>
                        {loading ? (
                          <>
                            <LoaderCircle className="mr-2 h-4 w-4 animate-spin" /> Loading
                          </>
                        ) : (
                          "Load Repository"
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="direct" className="mt-0">
                    <div className="flex flex-col md:flex-row gap-3">
                      <div className="flex-1 relative">
                        <div className="absolute left-3 top-2.5 text-muted-foreground">
                          <Download className="h-5 w-5" />
                        </div>
                        <Input
                          type="text"
                          placeholder="https://github.com/username/repo/blob/main/path/to/file.js"
                          className="pl-10"
                          value={directLink}
                          onChange={(e) => setDirectLink(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && handleDirectDownload()}
                        />
                        {directLink && (
                          <button
                            className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground"
                            onClick={() => setDirectLink("")}
                          >
                            <X className="h-5 w-5" />
                          </button>
                        )}
                      </div>
                      <Button 
                        onClick={handleDirectDownload} 
                        disabled={directDownloading || !directLink.trim()}
                      >
                        {directDownloading ? (
                          <>
                            <LoaderCircle className="mr-2 h-4 w-4 animate-spin" /> Downloading
                          </>
                        ) : (
                          "Download"
                        )}
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      Paste a direct link to a file or folder to download it instantly
                    </p>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Repository info */}
            {repoInfo && (
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                  <div>
                    <CardTitle className="text-xl">Repository Details</CardTitle>
                    <CardDescription className="mt-1.5">
                      <span className="font-medium">{repoInfo.owner}/{repoInfo.name}</span>
                    </CardDescription>
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleClearRepo}>
                    <X className="mr-2 h-4 w-4" /> Clear
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col md:flex-row md:items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">
                        {repoInfo.provider === "github" ? (
                          <Github className="h-4 w-4 mr-1" />
                        ) : (
                          <Gitlab className="h-4 w-4 mr-1" />
                        )}
                        {repoInfo.provider}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center">
                      <span className="text-sm text-muted-foreground mr-2">Branch:</span>
                      <Select value={branch} onValueChange={handleBranchChange} disabled={branches.length === 0}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Select branch" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectGroup>
                            {branches.map((b) => (
                              <SelectItem key={b} value={b}>
                                {b}
                              </SelectItem>
                            ))}
                          </SelectGroup>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex-1 md:text-right">
                      {selectedItems.size > 0 && (
                        <Badge variant="secondary" className="text-xs">
                          {selectedItems.size} items selected ({getSelectedCount()} files)
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col md:flex-row items-start gap-3">
                  <Button
                    onClick={downloadSelectedFiles}
                    disabled={selectedItems.size === 0 || zipProgress !== null}
                    className="w-full md:w-auto"
                  >
                    {zipProgress !== null ? (
                      <>
                        <LoaderCircle className="mr-2 h-4 w-4 animate-spin" />
                        Creating ZIP ({zipProgress}%)
                      </>
                    ) : (
                      <>
                        <Download className="mr-2 h-4 w-4" />
                        Download Selected Files
                      </>
                    )}
                  </Button>
                  
                  {zipProgress !== null && (
                    <div className="w-full bg-secondary rounded-full h-2.5 mt-1.5">
                      <div
                        className="bg-primary h-2.5 rounded-full transition-all"
                        style={{ width: `${zipProgress}%` }}
                      ></div>
                    </div>
                  )}
                </CardFooter>
              </Card>
            )}

            {/* Empty state */}
            {!repoInfo && !loading && (
              <div className="flex flex-col items-center justify-center text-center border rounded-lg p-10 bg-accent/50">
                <div className="flex items-center">
                  <Github className="h-10 w-10 text-muted-foreground mr-3" />
                  <Gitlab className="h-10 w-10 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-xl font-medium">No Repository Loaded</h3>
                <p className="mt-2 text-muted-foreground max-w-md">
                  Enter a GitHub or GitLab repository URL above to browse and download files
                </p>
                <p className="mt-3 text-sm text-muted-foreground">
                  Examples:<br/>
                  Repository: https://github.com/facebook/react<br/>
                  Direct file: https://github.com/facebook/react/blob/main/LICENSE<br/>
                  Direct folder: https://github.com/facebook/react/tree/main/packages
                </p>
              </div>
            )}
          </div>
        </div>
      </SidebarLayout>
    </ThemeProvider>
  );
};

export default Index;
