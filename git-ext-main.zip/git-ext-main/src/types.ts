
export type GitProvider = "github" | "gitlab";

export interface ThemeProviderProps {
  children: React.ReactNode;
  defaultTheme?: string;
  storageKey?: string;
}

export interface ThemeProviderState {
  theme: string;
  setTheme: (theme: string) => void;
}
