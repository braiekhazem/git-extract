
import React, { useState, useEffect } from "react";
import { ChevronDown, ChevronRight, Folder, LoaderCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { FileItem } from "@/lib/api";
import { FileTreeItem } from "@/components/file-tree-item";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";

interface FileExplorerProps {
  files: FileItem[];
  loading: boolean;
  onToggleNode: (path: string) => void;
  onToggleSelect: (item: FileItem, selected: boolean) => void;
  expandedNodes: Set<string>;
  selectedItems: Set<string>;
  collapsed?: boolean;
}

export function FileExplorer({
  files,
  loading,
  onToggleNode,
  onToggleSelect,
  expandedNodes,
  selectedItems,
  collapsed = false,
}: FileExplorerProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredFiles, setFilteredFiles] = useState<FileItem[]>(files);

  // Update filtered files when files or search term changes
  useEffect(() => {
    if (!searchTerm) {
      setFilteredFiles(files);
      return;
    }

    const searchTermLower = searchTerm.toLowerCase();
    const filterRecursive = (items: FileItem[]): FileItem[] => {
      return items
        .map((item) => {
          const nameMatch = item.name.toLowerCase().includes(searchTermLower);
          const pathMatch = item.path.toLowerCase().includes(searchTermLower);

          if (nameMatch || pathMatch) {
            return item;
          }

          if (item.children && item.children.length > 0) {
            const filteredChildren = filterRecursive(item.children);
            if (filteredChildren.length > 0) {
              return {
                ...item,
                children: filteredChildren,
              };
            }
          }

          return null;
        })
        .filter((item): item is FileItem => item !== null);
    };

    setFilteredFiles(filterRecursive(files));
  }, [files, searchTerm]);

  // Render file tree
  const renderTree = (items: FileItem[], level = 0) => {
    return items.map((item) => (
      <FileTreeItem
        key={item.path}
        item={item}
        level={level}
        expanded={expandedNodes.has(item.path)}
        selected={selectedItems.has(item.path)}
        onToggle={onToggleNode}
        onSelect={onToggleSelect}
        collapsed={collapsed}
      >
        {item.children &&
          expandedNodes.has(item.path) &&
          renderTree(item.children, level + 1)}
      </FileTreeItem>
    ));
  };

  // Select all files handler
  const handleSelectAll = (checked: boolean) => {
    const selectAllRecursive = (items: FileItem[]) => {
      items.forEach((item) => {
        onToggleSelect(item, checked);
        if (item.children) {
          selectAllRecursive(item.children);
        }
      });
    };

    selectAllRecursive(files);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="p-3 border-b flex items-center justify-between">
        <h3 className={cn("text-lg font-medium", collapsed && "sr-only")}>
          Files
        </h3>
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <Checkbox
              id="select-all"
              onCheckedChange={handleSelectAll}
              checked={selectedItems.size > 0 && selectedItems.size === countAllFiles(files)}
              className="rounded-sm h-4 w-4"
            />
            <label htmlFor="select-all" className="text-xs text-muted-foreground cursor-pointer">
              All
            </label>
          </div>
        )}
      </div>

      {!collapsed && (
        <div className="px-3 py-2">
          <input
            type="text"
            placeholder="Search files..."
            className="w-full px-3 py-1.5 text-sm rounded-md border"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      )}

      <ScrollArea className="flex-1">
        {loading ? (
          <div className="flex items-center justify-center p-4">
            <LoaderCircle className="h-6 w-6 animate-spin text-primary" />
            <span className={cn("ml-2", collapsed && "sr-only")}>Loading...</span>
          </div>
        ) : filteredFiles.length === 0 ? (
          <div className="p-4 text-sm text-muted-foreground text-center">
            {collapsed ? (
              <span className="sr-only">No files found</span>
            ) : searchTerm ? (
              "No files match your search"
            ) : (
              "No files in this repository"
            )}
          </div>
        ) : (
          <div className="py-2">{renderTree(filteredFiles)}</div>
        )}
      </ScrollArea>
    </div>
  );
}

// Helper function to count all files in the tree
function countAllFiles(items: FileItem[]): number {
  return items.reduce((count, item) => {
    if (item.children) {
      return count + countAllFiles(item.children) + 1;
    }
    return count + 1;
  }, 0);
}
