
import React from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Checkbox } from "@/components/ui/checkbox";
import { FileIcon } from "@/components/file-icon";
import { FileItem, formatFileSize, getFileExtension } from "@/lib/api";

interface FileTreeItemProps {
  item: FileItem;
  level: number;
  expanded: boolean;
  selected: boolean;
  onToggle: (path: string) => void;
  onSelect: (item: FileItem, selected: boolean) => void;
  children?: React.ReactNode;
  collapsed?: boolean;
}

export function FileTreeItem({
  item,
  level,
  expanded,
  selected,
  onToggle,
  onSelect,
  children,
  collapsed = false,
}: FileTreeItemProps) {
  const { name, path, type, size } = item;
  
  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggle(path);
  };

  const handleSelect = (checked: boolean) => {
    onSelect(item, checked);
  };

  const extension = getFileExtension(name);

  return (
    <div className="relative">
      <div
        className={cn(
          "flex items-center px-2 py-1 hover:bg-accent/50 cursor-pointer",
          selected && "bg-primary/10",
          collapsed && "justify-center"
        )}
        style={{ paddingLeft: collapsed ? 8 : `${(level + 1) * 12}px` }}
        onClick={() => type === "dir" && onToggle(path)}
      >
        {/* Toggle arrow for directories */}
        {type === "dir" && !collapsed && (
          <div
            className="mr-1 p-0.5 rounded-sm hover:bg-accent"
            onClick={handleToggle}
          >
            {expanded ? (
              <ChevronDown className="h-3.5 w-3.5" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5" />
            )}
          </div>
        )}
        
        {/* Checkbox for selection */}
        {!collapsed && (
          <Checkbox
            checked={selected}
            onCheckedChange={handleSelect}
            onClick={(e) => e.stopPropagation()}
            className="mr-2 h-3.5 w-3.5 rounded-sm"
          />
        )}
        
        {/* File/folder icon */}
        <FileIcon type={type} name={name} className={cn("h-4 w-4", collapsed && "h-5 w-5")} />
        
        {/* File name */}
        {!collapsed && (
          <span className="ml-1.5 text-sm truncate flex-1" title={name}>
            {name}
          </span>
        )}
        
        {/* File details (size, extension) */}
        {!collapsed && type === "file" && (
          <div className="flex items-center space-x-2 ml-auto pl-2">
            {extension && (
              <span className="text-xs px-1.5 py-0.5 bg-accent rounded-full">
                {extension}
              </span>
            )}
            {size !== undefined && (
              <span className="text-xs text-muted-foreground">
                {formatFileSize(size)}
              </span>
            )}
          </div>
        )}
      </div>
      
      {/* Children (for expanded directories) */}
      {children}
    </div>
  );
}
