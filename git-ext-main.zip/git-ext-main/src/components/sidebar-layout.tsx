
import React, { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface SidebarLayoutProps {
  children: React.ReactNode;
  sidebar: React.ReactNode;
  sidebarWidth?: number;
  minSidebarWidth?: number;
  defaultCollapsed?: boolean;
}

export function SidebarLayout({
  children,
  sidebar,
  sidebarWidth = 320,
  minSidebarWidth = 64,
  defaultCollapsed = false,
}: SidebarLayoutProps) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  // Determine if we're in mobile view
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;

  return (
    <div className="flex h-screen relative">
      {/* Sidebar for desktop */}
      <div
        className={`hidden md:flex flex-col border-r bg-sidebar transition-all duration-300 h-full ${
          collapsed ? "w-16" : ""
        }`}
        style={{ width: collapsed ? minSidebarWidth : sidebarWidth }}
      >
        {sidebar}
        <div className="flex justify-end p-1 border-t">
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full"
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>

      {/* Mobile sidebar drawer */}
      <div
        className={`fixed inset-0 bg-black/50 z-40 md:hidden transition-opacity duration-300 ${
          isMobileOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={() => setIsMobileOpen(false)}
      />

      <div
        className={`fixed left-0 top-0 bottom-0 bg-sidebar w-[280px] z-50 md:hidden transition-transform duration-300 ${
          isMobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {sidebar}
          <div className="flex justify-end p-1 border-t">
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full"
              onClick={() => setIsMobileOpen(false)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main content area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile toggle button */}
        <div className="md:hidden p-2 border-b">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMobileOpen(true)}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-auto">{children}</div>
      </div>
    </div>
  );
}
