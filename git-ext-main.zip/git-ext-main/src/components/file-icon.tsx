
import React from "react";
import { File, Folder, FolderOpen, FileCode, FileText, Image, Music, Video, Archive, Code, Film, FileJson, Paintbrush, Braces, Key, Lock, FileCheck, FileType, GitBranch } from "lucide-react";
import { cn } from "@/lib/utils";
import { getFileIcon } from "@/lib/api";

interface FileIconProps {
  type: "file" | "dir";
  name: string;
  className?: string;
  expanded?: boolean;
}

export function FileIcon({ type, name, className, expanded = false }: FileIconProps) {
  if (type === "dir") {
    return expanded ? (
      <FolderOpen className={cn("text-amber-500", className)} />
    ) : (
      <Folder className={cn("text-amber-500", className)} />
    );
  }
  
  // Get icon name based on file extension
  const iconName = getFileIcon(name);
  
  // Return appropriate icon component based on icon name
  switch (iconName) {
    case "code":
      return <FileCode className={cn("text-blue-500", className)} />;
    case "code-2":
      return <Code className={cn("text-orange-500", className)} />;
    case "file-text":
      return <FileText className={cn("text-gray-500", className)} />;
    case "image":
      return <Image className={cn("text-purple-500", className)} />;
    case "music":
      return <Music className={cn("text-pink-500", className)} />;
    case "video":
      return <Video className={cn("text-red-500", className)} />;
    case "film":
      return <Film className={cn("text-red-500", className)} />;
    case "archive":
      return <Archive className={cn("text-yellow-500", className)} />;
    case "paintbrush":
      return <Paintbrush className={cn("text-purple-500", className)} />;
    case "braces":
      return <Braces className={cn("text-green-500", className)} />;
    case "file-json":
      return <FileJson className={cn("text-green-500", className)} />;
    case "key":
      return <Key className={cn("text-yellow-500", className)} />;
    case "lock":
      return <Lock className={cn("text-gray-500", className)} />;
    case "file-check":
      return <FileCheck className={cn("text-green-500", className)} />;
    case "file-type":
      return <FileType className={cn("text-red-500", className)} />;
    case "git-branch":
      return <GitBranch className={cn("text-gray-500", className)} />;
    default:
      return <File className={cn("text-gray-500", className)} />;
  }
}
